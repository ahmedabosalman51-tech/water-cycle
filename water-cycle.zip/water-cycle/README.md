# رحلة قطرة ماء (Remotion)

npm install
npm run dev      # معاينة في Studio على المنفذ 3000
npm run render   # تصدير إلى out/water-cycle.mp4

لو ظهر خطأ عدم تطابق إصدارات: npx remotion upgrade
