import React from "react";
import {Composition} from "remotion";
import {WaterCycle} from "./WaterCycle";

export const FPS = 30;
export const DURATION = 15 * FPS; // 15 ثانية

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="WaterCycle"
      component={WaterCycle}
      durationInFrames={DURATION}
      fps={FPS}
      width={1080}
      height={1920}
    />
  );
};
