import React from "react";
import {
  AbsoluteFill,
  Easing,
  Sequence,
  interpolate,
  interpolateColors,
  spring,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import {loadFont} from "@remotion/google-fonts/Tajawal";

const {fontFamily} = loadFont("normal", {
  weights: ["500", "800"],
  subsets: ["arabic"],
});

// لوحة الألوان: ماء، صخر، شمس عنبرية
const C = {
  ink: "#0A2533",
  seaBack: "#1F7A96",
  seaFront: "#14607A",
  mist: "#EAF6F3",
  sun: "#F4B63F",
  drop: "#5CC8E0",
  rock: "#3E4E57",
  snow: "#F3F7F8",
};

const clamp = {
  extrapolateLeft: "clamp",
  extrapolateRight: "clamp",
} as const;

const ramp = (
  frame: number,
  from: number,
  to: number,
  a = 0,
  b = 1,
  easing: (t: number) => number = Easing.inOut(Easing.ease),
) => interpolate(frame, [from, to], [a, b], {...clamp, easing});

// تقدّم دوري من 0 إلى 1
const loop = (frame: number, start: number, period: number, offset: number) =>
  ((((frame - start - offset) % period) + period) % period) / period;

const wavePath = (
  frame: number,
  baseY: number,
  amp: number,
  len: number,
  speed: number,
  phase: number,
) => {
  let d = `M 0 ${baseY}`;
  for (let x = 0; x <= 1080; x += 20) {
    const y =
      baseY + Math.sin((x / len) * Math.PI * 2 + frame * speed + phase) * amp;
    d += ` L ${x} ${y}`;
  }
  return `${d} L 1080 1920 L 0 1920 Z`;
};

const Drop: React.FC<{
  x: number;
  y: number;
  s?: number;
  opacity?: number;
  fill?: string;
}> = ({x, y, s = 1, opacity = 1, fill = C.drop}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={opacity}>
    <path
      d="M0,-34 C10,-14 28,0 28,16 A28,28 0 0 1 -28,16 C-28,0 -10,-14 0,-34 Z"
      fill={fill}
    />
  </g>
);

const Caption: React.FC<{text: string}> = ({text}) => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  const opacity = interpolate(
    frame,
    [0, 10, durationInFrames - 10, durationInFrames],
    [0, 1, 1, 0],
    clamp,
  );
  const lift = ramp(frame, 0, 14, 24, 0, Easing.out(Easing.cubic));
  return (
    <AbsoluteFill
      style={{
        justifyContent: "flex-start",
        alignItems: "center",
        paddingTop: 1590,
        opacity,
        transform: `translateY(${lift}px)`,
      }}
    >
      <div
        dir="rtl"
        style={{
          width: 880,
          textAlign: "center",
          fontFamily,
          fontWeight: 800,
          fontSize: 66,
          lineHeight: 1.45,
          color: "white",
        }}
      >
        {text}
      </div>
    </AbsoluteFill>
  );
};

const Title: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const enter = spring({frame, fps, config: {damping: 14}});
  const opacity = ramp(frame, 70, 90, 1, 0);
  return (
    <AbsoluteFill
      style={{
        alignItems: "center",
        justifyContent: "flex-start",
        paddingTop: 640,
        opacity,
      }}
    >
      <div
        dir="rtl"
        style={{
          fontFamily,
          fontWeight: 800,
          fontSize: 150,
          color: C.ink,
          transform: `scale(${0.85 + enter * 0.15})`,
          opacity: enter,
        }}
      >
        رحلة قطرة ماء
      </div>
      <div
        dir="rtl"
        style={{
          fontFamily,
          fontWeight: 500,
          fontSize: 54,
          color: C.ink,
          marginTop: 12,
          opacity: ramp(frame, 20, 40),
        }}
      >
        كيف يدور الماء في الطبيعة
      </div>
    </AbsoluteFill>
  );
};

export const WaterCycle: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();

  // السماء تغمق قليلاً عند المطر
  const skyTop = interpolateColors(
    frame,
    [0, 250, 330, 430],
    ["#9ED7E6", "#9ED7E6", "#6E8F9C", "#9ED7E6"],
  );

  // الشمس
  const sunOpacity = interpolate(
    frame,
    [0, 250, 330, 330, 430],
    [1, 1, 0.25, 0.25, 1],
    clamp,
  );
  const sunPulse = 1 + Math.sin(frame / 14) * 0.03;

  // عنوان البداية: قطرة كبيرة
  const titleDrop = spring({frame, fps, config: {damping: 9}});
  const titleDropOpacity = ramp(frame, 70, 90, 1, 0);

  // التبخر
  const evapGlobal =
    ramp(frame, 80, 100) * ramp(frame, 260, 290, 1, 0);

  // الغيمة
  const cloudIn = spring({
    frame: frame - 170,
    fps,
    config: {damping: 200},
    durationInFrames: 70,
  });
  const cloudFill = interpolateColors(
    frame,
    [250, 320],
    [C.snow, "#A9BDC4"],
  );

  // المطر
  const rainGlobal = ramp(frame, 300, 312) * ramp(frame, 395, 412, 1, 0);

  // النهر
  const river = ramp(frame, 345, 425, 0, 1, Easing.inOut(Easing.cubic));

  return (
    <AbsoluteFill style={{backgroundColor: C.mist}}>
      <AbsoluteFill>
        <svg viewBox="0 0 1080 1920" width="100%" height="100%">
          <defs>
            <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor={skyTop} />
              <stop offset="1" stopColor={C.mist} />
            </linearGradient>
          </defs>
          <rect width="1080" height="1920" fill="url(#sky)" />

          {/* الشمس */}
          <g
            opacity={sunOpacity}
            transform={`translate(210 380) scale(${sunPulse})`}
          >
            <g transform={`rotate(${frame * 0.5})`}>
              {Array.from({length: 12}).map((_, i) => (
                <line
                  key={i}
                  x1="0"
                  y1="-150"
                  x2="0"
                  y2="-200"
                  stroke={C.sun}
                  strokeWidth="14"
                  strokeLinecap="round"
                  transform={`rotate(${i * 30})`}
                />
              ))}
            </g>
            <circle r="112" fill={C.sun} />
          </g>

          {/* الجبل */}
          <path
            d="M480,1400 L780,940 L900,1010 L1080,1180 L1080,1400 Z"
            fill={C.rock}
          />
          <path
            d="M735,1010 L780,940 L832,990 L800,1000 L775,985 L760,1010 Z"
            fill={C.snow}
          />

          {/* النهر */}
          <path
            d="M 790 1030 C 760 1120 840 1180 760 1250 S 700 1340 660 1415"
            fill="none"
            stroke={C.drop}
            strokeWidth="16"
            strokeLinecap="round"
            pathLength={1}
            strokeDasharray={1}
            strokeDashoffset={1 - river}
          />

          {/* الغيمة */}
          <g
            opacity={cloudIn}
            transform={`translate(545 590) scale(${cloudIn}) translate(-545 -590)`}
          >
            <circle cx="440" cy="610" r="90" fill={cloudFill} />
            <circle cx="545" cy="545" r="120" fill={cloudFill} />
            <circle cx="660" cy="595" r="100" fill={cloudFill} />
            <rect x="440" y="610" width="220" height="90" fill={cloudFill} />
            <circle cx="440" cy="655" r="45" fill={cloudFill} />
            <circle cx="660" cy="650" r="50" fill={cloudFill} />
          </g>

          {/* البحر */}
          <path d={wavePath(frame, 1400, 14, 360, 0.07, 0)} fill={C.seaBack} />
          <path
            d={wavePath(frame, 1450, 18, 300, -0.06, 2)}
            fill={C.seaFront}
          />

          {/* قطرة العنوان */}
          <Drop
            x={540}
            y={440}
            s={3.4 * titleDrop}
            opacity={titleDropOpacity}
          />

          {/* قطرات التبخر */}
          {Array.from({length: 7}).map((_, i) => {
            const p = loop(frame, 80, 80, i * 11);
            const x = 130 + i * 80 + Math.sin(p * 6 + i) * 18;
            const y = 1400 - p * 650;
            const o = Math.sin(p * Math.PI) * evapGlobal * 0.9;
            return (
              <Drop
                key={`e${i}`}
                x={x}
                y={y}
                s={0.7 - p * 0.25}
                opacity={o}
                fill={C.snow}
              />
            );
          })}

          {/* قطرات المطر */}
          {Array.from({length: 12}).map((_, i) => {
            const p = loop(frame, 300, 36, (i * 13) % 36);
            const x = 400 + i * 30;
            const y = 740 + p * 640;
            const o = (p > 0.88 ? (1 - p) / 0.12 : 1) * rainGlobal;
            return (
              <Drop key={`r${i}`} x={x} y={y} s={0.5} opacity={o} />
            );
          })}
        </svg>
      </AbsoluteFill>

      <Sequence durationInFrames={90}>
        <Title />
      </Sequence>

      <Sequence from={95} durationInFrames={105}>
        <Caption text="الشمس تسخّن البحر، فيتبخّر الماء" />
      </Sequence>
      <Sequence from={200} durationInFrames={100}>
        <Caption text="يرتفع البخار ويبرد، فيتجمّع غيوماً" />
      </Sequence>
      <Sequence from={300} durationInFrames={90}>
        <Caption text="تمطر الغيوم على الجبال" />
      </Sequence>
      <Sequence from={390} durationInFrames={60}>
        <Caption text="تعيده الأنهار إلى البحر، ويبدأ من جديد" />
      </Sequence>
    </AbsoluteFill>
  );
};
